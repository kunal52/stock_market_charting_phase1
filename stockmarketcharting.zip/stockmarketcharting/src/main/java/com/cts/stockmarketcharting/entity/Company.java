package com.cts.stockmarketcharting.entity;



import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name="company")
public class Company {

	@Id @NotNull
	@Column(name="company_code")
	private String companyCode;
	
	@NotNull
	@Column(name="company_name")
	private String companyName;

	@NotNull
	@Column(name="company_turnover")
	private double companyTurnover;
	
	@NotNull
	@Column(name="company_ceo")
	private String companyCeo;
	
	@NotNull
	@Column(name="company_board_of_directors")
	private String[] companyBoardOfDirectors;
	
	@NotNull
	@Column(name="company_listed_in_stock_exchanges")
	private int companyListedInStockExchanges;
	
	@OneToOne(cascade = CascadeType.ALL,targetEntity = Sector.class)
	private Sector sector;
	
	@NotNull
	@Column(name="company_brief_writeup")
	private String companyBriefWriteup;
	
	@OneToOne(cascade = CascadeType.ALL,targetEntity = StockExchange.class)
	private StockExchange stockExchange;

	public String getCompanyCode() {
		return companyCode;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public double getCompanyTurnover() {
		return companyTurnover;
	}

	public void setCompanyTurnover(double companyTurnover) {
		this.companyTurnover = companyTurnover;
	}

	public String getCompanyCeo() {
		return companyCeo;
	}

	public void setCompanyCeo(String companyCeo) {
		this.companyCeo = companyCeo;
	}

	public String[] getCompanyBoardOfDirectors() {
		return companyBoardOfDirectors;
	}

	public void setCompanyBoardOfDirectors(String[] companyBoardOfDirectors) {
		for(int index = 0 ; index < companyBoardOfDirectors.length ; index++)
		{
			this.companyBoardOfDirectors[index] = companyBoardOfDirectors[index];
		}
	}

	public int getCompanyListedInStockExchanges() {
		return companyListedInStockExchanges;
	}

	public void setCompanyListedInStockExchanges(int companyListedInStockExchanges) {
		this.companyListedInStockExchanges = companyListedInStockExchanges;
	}

	public Sector getSector() {
		return sector;
	}

	public void setSector(Sector sector) {
		this.sector = sector;
	}
	
}
