package com.cts.stockmarketcharting;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StockmarketchartingApplication {

	public static void main(String[] args) {
		SpringApplication.run(StockmarketchartingApplication.class, args);
	}

}
